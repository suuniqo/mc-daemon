class TimeoutExpired(Exception):
    pass
