class CommErr(Exception):
    pass


class RconErr(Exception):
    pass
