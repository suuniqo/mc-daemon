class ProcErr(Exception):
    pass
