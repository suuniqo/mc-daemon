class MntrErr(Exception):
    pass
