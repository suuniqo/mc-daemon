class ConfLoaderErr(Exception):
    pass
